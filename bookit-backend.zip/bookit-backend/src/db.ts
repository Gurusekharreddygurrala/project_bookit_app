import Database from 'better-sqlite3';

const db = new Database('travel.db');

// Create tables if not exist
db.exec(`
CREATE TABLE IF NOT EXISTS experiences (
  id INTEGER PRIMARY KEY,
  title TEXT,
  description TEXT
);

CREATE TABLE IF NOT EXISTS experience_details (
  id INTEGER PRIMARY KEY,
  details TEXT,
  slots TEXT  -- JSON string to store array of slots
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  experienceId INTEGER,
  slot INTEGER,
  name TEXT,
  email TEXT,
  FOREIGN KEY(experienceId) REFERENCES experiences(id)
);
`);

export default db;

import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import Database from 'better-sqlite3';

const app = express();
const PORT = process.env.PORT || 5000;
const db = new Database('travel.db');

app.use(cors());
app.use(bodyParser.json());

// Interfaces
interface CountResult { count: number; }
interface Experience {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
}
interface ExperienceDetails {
  experienceId: number;
  details: string;
  slots: string;
}
interface Promo {
  code: string;
  type: 'percentage' | 'flat';
  amount: number;
}
interface Booking {
  id: number;
  experienceId: number;
  slot: number;
  name: string;
  email: string;
  bookedAt: string;
}

// Create tables
db.prepare(`CREATE TABLE IF NOT EXISTS experiences (
  id INTEGER PRIMARY KEY,
  title TEXT,
  description TEXT,
  imageUrl TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS experience_details (
  experienceId INTEGER PRIMARY KEY,
  details TEXT,
  slots TEXT
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  experienceId INTEGER,
  slot INTEGER,
  name TEXT,
  email TEXT,
  bookedAt DATETIME DEFAULT CURRENT_TIMESTAMP
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS promos (
  code TEXT PRIMARY KEY,
  type TEXT,
  amount INTEGER
)`).run();

// Seed data (experiences, details, promos)
const expCount = db.prepare('SELECT COUNT(*) as count FROM experiences').get() as CountResult;
if (expCount.count === 0) {
  const experiences: Experience[] = [
    { id: 1, title: 'Beach Paradise', description: 'Relax on the sunny beaches.', imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb' },
    { id: 2, title: 'Mountain Adventure', description: 'Explore scenic mountain trails.', imageUrl: 'https://images.unsplash.com/photo-1465101178521-c1a5b1604854' },
    { id: 3, title: 'City Lights', description: 'Discover the vibrant city life.', imageUrl: 'https://images.unsplash.com/photo-1460983129604-30854a098b59' }
  ];
  const insertExp = db.prepare('INSERT INTO experiences(id, title, description, imageUrl) VALUES (?, ?, ?, ?)');
  const insertManyExp = db.transaction((items: Experience[]) => {
    for (const item of items) {
      insertExp.run(item.id, item.title, item.description, item.imageUrl);
    }
  });
  insertManyExp(experiences);
}

const detailsCount = db.prepare('SELECT COUNT(*) as count FROM experience_details').get() as CountResult;
if (detailsCount.count === 0) {
  const details: ExperienceDetails[] = [
    { experienceId: 1, details: 'Beautiful seaside sandy beaches with activities.', slots: JSON.stringify([9, 10, 14, 15]) },
    { experienceId: 2, details: 'Mountains and alpine hiking experiences.', slots: JSON.stringify([8, 12, 16]) },
    { experienceId: 3, details: 'City nightlife and cultural exploration.', slots: JSON.stringify([18, 20, 22]) }
  ];
  const insertDet = db.prepare('INSERT INTO experience_details(experienceId, details, slots) VALUES (?, ?, ?)');
  const insertManyDet = db.transaction((items: ExperienceDetails[]) => {
    for (const item of items) {
      insertDet.run(item.experienceId, item.details, item.slots);
    }
  });
  insertManyDet(details);
}

const promoCount = db.prepare('SELECT COUNT(*) as count FROM promos').get() as CountResult;
if (promoCount.count === 0) {
  const promos: Promo[] = [
    { code: 'SAVE10', type: 'percentage', amount: 10 },
    { code: 'FLAT100', type: 'flat', amount: 100 }
  ];
  const insertPromo = db.prepare('INSERT INTO promos(code, type, amount) VALUES (?, ?, ?)');
  const insertManyPromo = db.transaction((items: Promo[]) => {
    for (const item of items) {
      insertPromo.run(item.code, item.type, item.amount);
    }
  });
  insertManyPromo(promos);
}

// Middleware for logging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// API Endpoints

// Get all experiences
app.get('/api/experiences', (req, res) => {
  try {
    const experiences = db.prepare('SELECT * FROM experiences').all() as Experience[];
    res.json(experiences);
  } catch (e) {
    res.status(500).json({ message: 'Failed to fetch experiences' });
  }
});

// Get experience details by ID
app.get('/api/experiences/:id', (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid experience ID' });
    }
    const experience = db.prepare('SELECT * FROM experiences WHERE id = ?').get(id) as Experience | undefined;
    if (!experience) return res.status(404).json({ message: 'Experience not found' });

    const detail = db.prepare('SELECT * FROM experience_details WHERE experienceId = ?').get(id) as ExperienceDetails | undefined;
    if (!detail) return res.status(404).json({ message: 'Experience details not found' });

    const slots = JSON.parse(detail.slots);
    res.json({ ...experience, details: detail.details, slots });
  } catch {
    res.status(500).json({ message: 'Failed to fetch experience details' });
  }
});

// Validate promo code
app.post('/api/promo/validate', (req, res) => {
  try {
    const { code, price } = req.body;
    if (!code || price === undefined) {
      return res.status(400).json({ message: 'Code and price are required' });
    }
    const promo = db.prepare('SELECT * FROM promos WHERE code = ?').get(code) as Promo | undefined;
    if (!promo) return res.status(400).json({ message: 'Invalid promo code' });

    let discount = 0;
    if (promo.type === 'percentage') discount = (price * promo.amount) / 100;
    else if (promo.type === 'flat') discount = promo.amount;

    const finalPrice = Math.max(price - discount, 0);
    res.json({ discount, finalPrice });
  } catch {
    res.status(500).json({ message: 'Promo validation failed' });
  }
});

// Create a booking
app.post('/api/bookings', (req, res) => {
  try {
    const { experienceId, slot, name, email } = req.body;
    if (!experienceId || !slot || !name || !email) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    const existingBooking = db.prepare('SELECT * FROM bookings WHERE experienceId = ? AND slot = ?').get(experienceId, slot);
    if (existingBooking) return res.status(409).json({ message: 'Slot already booked' });

    db.prepare('INSERT INTO bookings (experienceId, slot, name, email) VALUES (?, ?, ?, ?)').run(experienceId, slot, name, email);
    res.json({ message: 'Booking successful' });
  } catch {
    res.status(500).json({ message: 'Booking failed' });
  }
});

// Get all bookings
app.get('/api/bookings', (req, res) => {
  try {
    const bookings = db.prepare(`
      SELECT b.id, b.experienceId, e.title AS experienceTitle,
             b.slot, b.name, b.email, b.bookedAt 
      FROM bookings b
      JOIN experiences e ON b.experienceId = e.id
      ORDER BY b.bookedAt DESC
    `).all() as Booking[];
    res.json(bookings);
  } catch {
    res.status(500).json({ message: 'Failed to fetch bookings' });
  }
});

// Delete booking by ID
app.delete('/api/bookings/:id', (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid booking ID' });
    }
    const existingBooking = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
    if (!existingBooking) return res.status(404).json({ message: 'Booking not found' });

    db.prepare('DELETE FROM bookings WHERE id = ?').run(id);
    res.json({ message: 'Booking deleted successfully' });
  } catch {
    res.status(500).json({ message: 'Failed to delete booking' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

interface Experience {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
}

const experiences: Experience[] = [
  {
    id: 1,
    title: 'Beach Paradise',
    description: 'Relax on the sunny beaches.',
    imageUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb',
  },
  {
    id: 2,
    title: 'Mountain Adventure',
    description: 'Explore scenic mountain trails.',
    imageUrl: 'https://images.unsplash.com/photo-1465101178521-c1a5b1604854',
  },
  {
    id: 3,
    title: 'City Lights',
    description: 'Discover the vibrant city life.',
    imageUrl: 'https://images.unsplash.com/photo-1460983129604-30854a098b59',
  },
];

db.prepare(`
  CREATE TABLE IF NOT EXISTS experiences (
    id INTEGER PRIMARY KEY,
    title TEXT,
    description TEXT,
    imageUrl TEXT
  )
`).run();

const insertExperience = db.prepare(
  'INSERT INTO experiences (id, title, description, imageUrl) VALUES (?, ?, ?, ?)'
);

// Use any[] because better-sqlite3 types are generic:
const insertMany = db.transaction((items: Experience[]) => {
  for (const exp of items) {
    insertExperience.run(exp.id, exp.title, exp.description, exp.imageUrl);
  }
});

insertMany(experiences);

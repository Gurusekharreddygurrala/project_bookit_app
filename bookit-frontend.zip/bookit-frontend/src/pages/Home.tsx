import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Experience {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
}

const Home: React.FC = () => {
  const [experiences, setExperiences] = useState<Experience[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/experiences')
      .then(res => {
        if (!res.ok) throw new Error('API error');
        return res.json();
      })
      .then(data => {
        setExperiences(data);
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to load experiences.');
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-center mt-8">Loading...</div>;
  if (error) return <div className="text-red-500 text-center mt-8">{error}</div>;

  return (
    <div className="container mx-auto py-6 px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
      {experiences.map(exp => (
        <div
          key={exp.id}
          className="border p-4 rounded cursor-pointer hover:shadow-lg"
          onClick={() => navigate(`/details/${exp.id}`)}
        >
          <img
            src={exp.imageUrl || 'https://via.placeholder.com/200x120?text=No+Image'}
            alt={exp.title}
            className="w-full h-40 object-cover rounded"
          />
          <h3 className="text-lg font-bold mt-3">{exp.title}</h3>
          <p className="text-sm text-gray-700">{exp.description}</p>
        </div>
      ))}
    </div>
  );
};

export default Home;

import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

interface Experience {
  id: number;
  title: string;
  description: string;
  imageUrl?: string;
  details: string;
  slots: number[];
}

const Details: React.FC = () => {
  const { id } = useParams();
  const [exp, setExp] = useState<Experience | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (!id) return;
    fetch(`/api/experiences/${id}`)
      .then(res => {
        if (!res.ok) throw new Error('API error');
        return res.json();
      })
      .then(data => {
        setExp(data);
        setLoading(false);
      })
      .catch(() => {
        setError('Experience not found.');
        setLoading(false);
      });
  }, [id]);

  if (loading) return <div className="text-center mt-8">Loading...</div>;
  if (error) return <div className="text-red-500 text-center mt-8">{error}</div>;
  if (!exp) return null;

  return (
    <div className="max-w-xl mx-auto p-6">
      <img src={exp.imageUrl || ''} alt={exp.title} className="w-full h-56 object-cover rounded" />
      <h2 className="text-2xl font-bold mt-4">{exp.title}</h2>
      <p className="mt-2">{exp.description}</p>
      <div className="mt-4">
        <strong>Details:</strong> {exp.details}
      </div>
      <div className="mt-4">
        <strong>Available Slots:</strong>
        <div className="flex gap-2 mt-2">
          {exp.slots.map(slot => (
            <button key={slot}
              className="border rounded px-3 py-1"
              onClick={() => navigate('/checkout', { state: { exp, slot } })}
            >
              {slot}:00
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Details;

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const Result: React.FC = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const success = state?.success;
  const message = state?.message;

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h2 className={success ? "text-2xl text-green-600" : "text-2xl text-red-600"}>
        {success ? 'Booking Successful!' : 'Booking Failed'}
      </h2>
      <div className="mt-2">{message}</div>
      <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded" onClick={() => navigate('/')}>Back to Home</button>
    </div>
  );
};

export default Result;

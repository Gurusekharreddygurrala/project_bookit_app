import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const Checkout: React.FC = () => {
  const { state } = useLocation();
  const navigate = useNavigate();
  const exp = state?.exp;
  const slot = state?.slot;

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [promo, setPromo] = useState('');
  const [price, setPrice] = useState(500); // Example
  const [discount, setDiscount] = useState(0);
  const [finalPrice, setFinalPrice] = useState(500);
  const [promoError, setPromoError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!exp || !slot) return <div className="mt-10 text-center text-red-500">Please select an experience and slot.</div>;

  const validatePromo = async () => {
    setPromoError('');
    setLoading(true);
    const res = await fetch('/api/promo/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: promo, price }),
    });
    const data = await res.json();
    if (res.ok) {
      setDiscount(data.discount);
      setFinalPrice(data.finalPrice);
    } else {
      setPromoError(data.message || 'Invalid code');
      setDiscount(0);
      setFinalPrice(price);
    }
    setLoading(false);
  };

  const book = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        experienceId: exp.id,
        slot,
        name,
        email
      }),
    });
    const data = await res.json();
    setLoading(false);
    navigate('/result', { state: { success: res.ok, message: data.message } });
  };

  return (
    <div className="max-w-lg mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Booking: {exp.title} at {slot}:00</h2>
      <form onSubmit={book} className="grid gap-3">
        <input value={name} onChange={e => setName(e.target.value)} required placeholder="Name" className="border px-2 py-1 rounded" />
        <input value={email} onChange={e => setEmail(e.target.value)} required type="email" placeholder="Email" className="border px-2 py-1 rounded" />
        <div className="flex gap-2 items-center">
          <input value={promo} onChange={e => setPromo(e.target.value)} placeholder="Promo Code" className="border px-2 py-1 rounded" />
          <button type="button" onClick={validatePromo} className="px-3 py-1 border rounded" disabled={loading}>Apply</button>
        </div>
        {promoError && <div className="text-red-500">{promoError}</div>}
        <div>
          <div>Base Price: {price} INR</div>
          <div>Discount: {discount} INR</div>
          <div className="font-bold">Final Price: {finalPrice} INR</div>
        </div>
        <button type="submit" className="py-2 px-4 rounded bg-blue-600 text-white" disabled={loading}>{loading ? 'Booking...' : 'Book Now'}</button>
      </form>
    </div>
  );
};

export default Checkout;
